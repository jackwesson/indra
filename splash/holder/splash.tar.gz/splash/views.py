#original 
from django.shortcuts import render

# from video https://www.youtube.com/watch?v=Txxa-NP1gXs&list=PLei96ZX_m9sXxvAlhV6El4HnpaClQOXa9&index=2
from django.shortcuts import render_to_response
from django.template import RequestContext
from django import template
from django.template.loader import get_template 
from django.http import HttpResponseRedirect


# working with forms
from .forms import NameForm

#original
from django.http import HttpResponse

# Create your views here.


#  https://www.youtube.com/watch?v=VtNHVuJq93U
# potentially useful video series


def splash(request):
    # if this is a POST request we need to process the form data
    if request.method == 'POST':
        # create a form instance and populate it with data from the request:
        form = NameForm(request.POST or None)
        # check whether it's valid:
        if form.is_valid():
            # process the data in form.cleaned_data as required
            # ...
            # redirect to a new URL:
            return HttpResponseRedirect('/thanks/')

    # if a GET (or any other method) we'll create a blank form
    else:
        form = NameForm()

    return render(request, 'name.html', {'form': form})
    
    
    
    # template = get_template('djangosocialtwodo/splash.html')
    # return HttpResponse(render(template, request))
        
    
    # return render(request, 'djangosocialtwodo/splash.html')
    # return render_to_response('djangosocialtwodo/splash.html', {}, RequestContext(request))
    #return HttpResponse("Hello, world. You're at the splash index.")
    
def say_whatsup(request):
    return HttpResponse("Hello, WHAT IS UP?")
    
    # django-admin startapp users
    # create a file called urls .py in new subapp
    # edit social_todo/urls following the model of tasks to route to new subapp