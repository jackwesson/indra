from django import forms


# your_name = forms.CharField(label='Your name', max_length=100)
class NameForm(forms.Form):
    user = forms.EmailField(label='Your Email', max_length=50)
    password = forms.CharField(label='Your password', max_length=50)    